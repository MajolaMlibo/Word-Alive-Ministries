const readings = {
  "2026-08-27": {ref:"Romans 8:1–17", theme:"Walking in the Spirit", quote:"There is therefore now no condemnation for those who are in Christ Jesus, who walk not according to the flesh but according to the Spirit."},
  "2026-08-28": {ref:"Romans 8:18–39", theme:"The Hope of Glory", quote:"For I consider that the sufferings of this present time are not worth comparing with the glory that is to be revealed to us."},
  "2026-08-29": {ref:"Romans 9:1–18", theme:"God's Purpose", quote:"So then it depends not on human will or exertion, but on God, who has mercy."},
  "2026-08-30": {ref:"Romans 9:19–33", theme:"The Righteousness of Faith", quote:"Behold, I am laying in Zion a stone of stumbling, and a rock of offense."},
  "2026-08-31": {ref:"Romans 10:1–21", theme:"Faith Comes by Hearing", quote:"So faith comes from hearing, and hearing through the word of Christ."},
  "2026-09-01": {ref:"Romans 11:1–24", theme:"The Mercy of God", quote:"For God has consigned all to disobedience, that he may have mercy on all."}
};

let state = JSON.parse(localStorage.getItem("wam_state") || '{"completed":[]}');
const save=()=>localStorage.setItem("wam_state",JSON.stringify(state));
const todayKey="2026-09-01";
const getReading=(key=todayKey)=>readings[key]||readings["2026-08-27"];

function navigate(page){
  const app=document.getElementById("app");
  document.querySelectorAll(".bottom-nav button").forEach(b=>b.classList.toggle("active",b.dataset.page===page));
  const r=getReading();
  if(page==="home") app.innerHTML=home();
  if(page==="bible") app.innerHTML=reading();
  if(page==="calendar") app.innerHTML=calendar();
  if(page==="study") app.innerHTML=study();
  if(page==="profile") app.innerHTML=profile();
}
function home(){
 const r=getReading(); const pct=Math.round(state.completed.length/6*100);
 return `<div class="page">
  <section class="hero"><h1>Good Morning 👋</h1><p>Welcome to Word Alive Ministries. Let's grow together in God's Word.</p></section>
  <section class="card"><div class="section-title">📖 TODAY'S SCRIPTURE <span class="small" style="color:#fff">1 SEPTEMBER 2026</span></div>
   <div class="scripture-ref">${r.ref}</div><div class="theme">${r.theme}</div><p class="verse">“${r.quote}”</p>
   <button class="btn" onclick="navigate('bible')">READ TODAY'S SCRIPTURE ›</button>
  </section>
  <div class="grid"><section class="card"><div class="section-title">📅 NEXT BIBLE STUDY</div><h2>Romans 11</h2><p>Thursday • 19:00 – 20:00</p><button class="btn" onclick="navigate('calendar')">VIEW CALENDAR ›</button></section>
  <section class="card"><div class="section-title">📊 YOUR PROGRESS</div><p><b>Reading Streak</b> 🔥 12 Days</p><div class="progress-bar"><div style="width:${Math.min(pct,100)}%"></div></div><p>${state.completed.length} of 6 readings completed • ${pct}%</p><button class="btn" onclick="navigate('profile')">VIEW PROGRESS ›</button></section></div>
  <section class="card"><div class="section-title">📚 QUICK ACCESS</div><div class="quick">
   <button onclick="navigate('bible')">📖<br>Today's Reading</button><button onclick="navigate('calendar')">📅<br>Study Calendar</button><button onclick="navigate('study')">📚<br>Align & Prosper</button><button onclick="navigate('prayer')">🙏<br>Prayer</button>
  </div></section>
  <div class="notice">📢 <b>Ministry Update</b><br>Join us for our Align & Prosper Bible Study this Thursday at 7PM.</div>
 </div>`;
}
function reading(){
 const r=getReading(); const done=state.completed.includes(todayKey);
 return `<div class="page"><section class="card"><div class="section-title">📖 TODAY'S READING</div><div class="scripture-ref">${r.ref}</div><div class="theme">${r.theme}</div><p class="verse">${r.quote}</p>
 <p style="line-height:1.6">Today, take time to read the full passage in your preferred Bible translation. Reflect on the context, write down what the Spirit highlights, and pray the Word into your life.</p>
 <button class="btn ${done?'secondary':''}" onclick="completeToday()">${done?'✓ READING COMPLETED':'✓ MARK AS COMPLETED'}</button></section>
 <div class="grid"><button class="btn secondary" onclick="navigate('calendar')">‹ PREVIOUS</button><button class="btn" onclick="navigate('calendar')">NEXT ›</button></div></div>`;
}
function calendar(){
 let days=["24","25","26","27","28","29","30","31","1","2","3","4","5","6","7","8","9","10","11","12","13"];
 return `<div class="page"><section class="card"><div class="section-title">📅 BIBLE STUDY CALENDAR</div><h2 style="text-align:center">SEPTEMBER 2026</h2><div class="calendar">${days.map((d,i)=>`<div class="day ${d==="1"?"today":""} ${d==="27"?"done":""}" onclick="calendarDay('${d}')">${d}</div>`).join("")}</div></section>
 <section class="card"><div class="section-title">📚 1 SEPTEMBER 2026</div><div class="list-item"><span>📖 Daily Scripture<br><b>${getReading().ref}</b></span><span>›</span></div><div class="list-item"><span>📚 Bible Study<br><b>Romans 11</b></span><span>›</span></div><div class="list-item"><span>✦ Theme<br><b>${getReading().theme}</b></span><span>›</span></div><button class="btn" onclick="navigate('bible')">VIEW READING</button></section></div>`;
}
function study(){
 return `<div class="page"><section class="hero"><h1>Align & Prosper</h1><p>Bible Study • Follow Him Elohim</p></section><section class="card"><div class="section-title">📚 CURRENT STUDY</div><h2>Romans</h2><p><b>Current chapter:</b> Romans 11</p><div class="progress-bar"><div style="width:70%"></div></div><p>Progress: 70%</p><button class="btn">CONTINUE STUDY ›</button></section>
 <section class="card"><div class="section-title">✓ COMPLETED BOOKS</div>${["Genesis","Matthew","Exodus","Leviticus","Mark","Numbers","Deuteronomy","John","Joshua","Judges","Acts","Romans","Ruth","1 Samuel","2 Samuel","James","1 Kings","2 Kings","1 Corinthians","1 Chronicles","Psalm 1–50","2 Chronicles","Ezra"].map(x=>`<div class="list-item"><span>✓ ${x}</span></div>`).join("")}</section></div>`;
}
function profile(){
 return `<div class="page"><section class="card" style="text-align:center"><img src="logo.jpg" style="width:90px;height:90px;border-radius:50%;object-fit:cover;border:3px solid #eeb522"><h2>My Profile</h2><p class="small">Word Alive Ministries</p><div class="grid"><div><b>${state.completed.length}</b><br><span class="small">Readings</span></div><div><b>23</b><br><span class="small">Books</span></div></div></section>
 <section class="card">${["📖 Reading History","🔖 Bookmarks","📝 Notes","🙏 Prayer Journal","🔔 Notification Settings","🌙 Dark Mode","⚙ Account Settings","ℹ About Word Alive Ministries"].map(x=>`<div class="list-item"><span>${x}</span><span>›</span></div>`).join("")}</section></div>`;
}
function completeToday(){ if(!state.completed.includes(todayKey)) state.completed.push(todayKey); save(); navigate("bible"); }
function toggleMenu(){document.getElementById("menu").classList.toggle("open")}
function closeMenu(){document.getElementById("menu").classList.remove("open")}
function showNotifications(){alert("Daily Scripture notification: Romans 11:1–24 — The Mercy of God");}
function calendarDay(d){ if(d==="1") navigate("bible"); }
function prayer(){ document.getElementById("app").innerHTML=`<div class="page"><section class="card"><div class="section-title">🙏 PRAYER</div><p class="verse">“Cast all your anxiety on Him, because He cares for you.”</p><p style="text-align:center">1 Peter 5:7</p><textarea class="field" rows="8" placeholder="Write your prayer..."></textarea><button class="btn" onclick="alert('Prayer saved privately on this device.')">SAVE PRAYER</button></section></div>`; }
navigate("home");
if("serviceWorker" in navigator) navigator.serviceWorker.register("service-worker.js");
